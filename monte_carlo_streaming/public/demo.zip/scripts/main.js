$(window).bind("load", function() {

  $.ajax({
    url: '/stocks',
    type: 'get',
    dataType: 'json',
    success: function(data) {
      data.forEach(function (stock) {
        price_and_position(stock);
      })}
    });

  $.ajax({
    url: '/spark?stocks=RHT,HDP,GOOG,AMZN,YHOO,GE,TWTR',
    type: 'get',
    dataType: 'json',
    success: function(data) {
      $("#liquidity").text("$" + data.liquidityrisk);
    }

  });

  function price_and_position(stock) {
     $.ajax({
      url: 'ticker/' + stock,
      type: 'get',
      success: function(data) {
        console.log(data);
        $("#" + stock + " .stock").text(data);
      }});

      $.ajax({
      url: '/position/' + stock,
      type: 'get',
      success: function(data) {
        console.log(data);
        $("#" + stock + " .position").text(data);
      }})
  }
});