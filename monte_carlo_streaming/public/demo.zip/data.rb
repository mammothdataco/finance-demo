require 'sinatra'
require 'json'
require 'pry'
require 'bigdecimal'

class DataGrid
 
  def initialize
    @auth = 'Authorization: Basic ZGF0YWdyaWQ6UmVkSGF0RGVtbyQy'
    @url = "http://ec2-54-68-56-201.us-west-2.compute.amazonaws.com:8080/rest/default/{{replace}}"
    @read_curl = "curl -H '#{@auth}' -X GET #{@url}"
    @write_curl = "curl -H '#{@auth}' -X PUT #{@url} -H 'Content-type: text/plain' -d '{{value}}'"
  end

 def get(key:)
  cmdline = @read_curl.gsub("{{replace}}", key)
  `#{cmdline}`
 end

 def put(key:, value:)
  cmdline = @write_curl.gsub("{{replace}}", key)
  cmdline.gsub!("{{value}}", value)
  `#{cmdline}`
 end

end

def round(val)
  val = val.to_f
  sprintf "%.2f", val
end

$grid = DataGrid.new


get '/spark' do
  puts params['stocks']
  $grid.put(key: 'stocklist', value: params['stocks'])
  system " /mnt/pd1/hadoop/spark/bin/spark-submit --class com.mammothdata.liquidityrisk.LiquidityRiskMonteCarlo ~/liquidity-
monte-carlo.jar"
  { liquidityrisk: round($grid.get(key: 'liquidityrisk')) }.to_json
end

get '/stocks' do
  $grid.get(key: "stocklist").split(',').to_json
end

get '/ticker/:ticker' do |ticker|
  $grid.get(key: "#{ticker}_stock")
end

get '/position/:ticker' do |ticker|
  $grid.get(key: "#{ticker}_position")
end

get '/position/:ticker/:position' do |ticker, position|
  $grid.put(key: "#{ticker}_position", value: position)
end